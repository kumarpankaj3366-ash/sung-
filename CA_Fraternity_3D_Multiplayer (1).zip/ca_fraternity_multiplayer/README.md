# CA Fraternity 3D — Multiplayer Campus

A starter 3D browser game for the CA fraternity. Players can join a room, walk around a virtual campus, see other players move live, chat, answer CA-themed quiz questions, earn XP, and view a room leaderboard.

## Stack
- Three.js (3D browser rendering, loaded from jsDelivr CDN)
- Node.js + Express (web server)
- Socket.IO (real-time rooms, movement, chat, score updates)

## Requirements
- Node.js 18 or newer
- Internet connection on first run for the Three.js module and Google Fonts CDN
- A modern browser with WebGL enabled

## Run locally
1. Install Node.js LTS from https://nodejs.org/
2. Extract this ZIP.
3. Open a terminal in the extracted `ca_fraternity_multiplayer` folder.
4. Run:

   ```bash
   npm install
   npm start
   ```

5. Open http://localhost:3000
6. Open the same URL in multiple tabs or devices on the same network to test multiplayer.
7. Enter a display name and room code. Players with the same room code meet in the same campus.

To stop the server, press `Ctrl+C` in the terminal.

## Controls
- WASD or arrow keys: move
- Drag with the mouse: orbit camera
- Mouse wheel: zoom
- Campus Activities panel: start a CA quiz

## Try it with friends on your Wi-Fi
Run the server on one computer. Find that computer's local IP address and have other devices on the same Wi-Fi open `http://YOUR_LOCAL_IP:3000`. Allow Node.js through the operating system firewall if prompted.

## Deploy publicly
Deploy to a Node.js host that supports long-lived WebSocket connections (for example, a VPS or a compatible app platform):
1. Upload the project folder or connect its Git repository.
2. Set the build/install step to `npm install`.
3. Set the start command to `npm start`.
4. Configure the host to route public HTTP traffic to the assigned `PORT`.
5. Use HTTPS at the hosting layer.
6. Test with multiple devices and check the host's WebSocket support.

Do not deploy this demo with personal data or assume it is production-hardened.

## Current scope and limitations
- Room cap is 100 simultaneous sockets per room. Real capacity depends on host CPU, network, message frequency, and browser/device performance; load-test before promising 100-player production capacity.
- This is a prototype, not an authenticated or moderated public community.
- Positions are relayed in real time, but this is not a fully authoritative anti-cheat simulation.
- Quiz questions and score are demo data; scores reset when a player leaves.
- Chat is room-wide, rate-limited, and not persisted.
- The client loads Three.js from a CDN. For offline deployment, install/bundle Three.js locally.
- Add authentication, persistent profiles, moderation/reporting, HTTPS, monitoring, and server-side validation before a public launch.

## Suggested next upgrades
1. Persistent user accounts and CA stage tags (Foundation / Inter / Final / Qualified).
2. Voice rooms and private party invites.
3. More quiz packs for Accounting, Audit, GST, DT, FM, and Law.
4. Save XP and leaderboards in PostgreSQL.
5. Admin moderation and reporting tools.
6. Better campus collision, mobile touch controls, and avatar customization.
