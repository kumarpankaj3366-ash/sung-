const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  maxHttpBufferSize: 1e6,
  cors: { origin: false }
});

const PORT = process.env.PORT || 3000;
const MAX_PLAYERS_PER_ROOM = 100;
const rooms = new Map();
const lastChatAt = new Map();

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, rooms: rooms.size }));

function cleanName(value) {
  return String(value || "CA Learner").replace(/[<>]/g, "").trim().slice(0, 18) || "CA Learner";
}
function cleanRoom(value) {
  return String(value || "MAIN").toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 12) || "MAIN";
}
function roomPlayers(roomId) {
  if (!rooms.has(roomId)) rooms.set(roomId, new Map());
  return rooms.get(roomId);
}
function publicPlayer(p) {
  return { id: p.id, name: p.name, x: p.x, z: p.z, color: p.color, score: p.score };
}
function emitRoomState(roomId) {
  const players = roomPlayers(roomId);
  io.to(roomId).emit("players", Array.from(players.values(), publicPlayer));
}

io.on("connection", socket => {
  let currentRoom = null;
  let player = null;

  socket.on("join", payload => {
    if (currentRoom) return;
    const roomId = cleanRoom(payload && payload.room);
    const players = roomPlayers(roomId);
    if (players.size >= MAX_PLAYERS_PER_ROOM) {
      socket.emit("joinError", "This room is full. Try another room code.");
      return;
    }
    player = {
      id: socket.id,
      name: cleanName(payload && payload.name),
      x: (Math.random() - 0.5) * 8,
      z: (Math.random() - 0.5) * 8,
      color: ["#40c4ff", "#ffca28", "#ff7eb6", "#80cbc4", "#b39ddb", "#ff8a65"][Math.floor(Math.random() * 6)],
      score: 0
    };
    currentRoom = roomId;
    socket.join(roomId);
    players.set(socket.id, player);
    socket.emit("joined", { id: socket.id, room: roomId, maxPlayers: MAX_PLAYERS_PER_ROOM });
    socket.emit("players", Array.from(players.values(), publicPlayer));
    socket.to(roomId).emit("systemMessage", `${player.name} joined the campus.`);
    emitRoomState(roomId);
  });

  socket.on("move", pos => {
    if (!currentRoom || !player || !pos) return;
    const x = Number(pos.x), z = Number(pos.z);
    if (!Number.isFinite(x) || !Number.isFinite(z)) return;
    // Bound the playable campus and avoid accepting arbitrary remote coordinates.
    player.x = Math.max(-24, Math.min(24, x));
    player.z = Math.max(-24, Math.min(24, z));
    socket.to(currentRoom).volatile.emit("playerMoved", { id: player.id, x: player.x, z: player.z });
  });

  socket.on("chat", raw => {
    if (!currentRoom || !player) return;
    const now = Date.now();
    if (now - (lastChatAt.get(socket.id) || 0) < 700) return;
    lastChatAt.set(socket.id, now);
    const text = String(raw || "").replace(/[<>]/g, "").trim().slice(0, 180);
    if (!text) return;
    io.to(currentRoom).emit("chatMessage", {
      name: player.name,
      text,
      at: new Date().toISOString()
    });
  });

  socket.on("quizCorrect", () => {
    if (!currentRoom || !player) return;
    player.score += 10;
    io.to(currentRoom).emit("scoreUpdate", { id: player.id, score: player.score, name: player.name });
  });

  socket.on("disconnect", () => {
    if (currentRoom && rooms.has(currentRoom)) {
      const players = rooms.get(currentRoom);
      if (player) players.delete(socket.id);
      socket.to(currentRoom).emit("systemMessage", `${player ? player.name : "A player"} left the campus.`);
      emitRoomState(currentRoom);
      if (players.size === 0) rooms.delete(currentRoom);
    }
    lastChatAt.delete(socket.id);
  });
});

server.listen(PORT, () => {
  console.log(`CA Fraternity multiplayer running at http://localhost:${PORT}`);
});